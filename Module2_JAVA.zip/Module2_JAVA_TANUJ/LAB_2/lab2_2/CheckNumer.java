package com.lab2;

public class CheckNumer {
	public static void main(String[] args) {
		String cmdArgs = args[0];
		int mainValue = Integer.parseInt(cmdArgs);
		
		if(mainValue > 0){
			System.out.println("Given Number is POSITIVE Number");
		}else{
			System.out.println("Given Number is NEGATIVE Number");
		}
	}
}
