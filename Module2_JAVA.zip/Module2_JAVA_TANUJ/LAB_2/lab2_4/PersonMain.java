package com.lab2_4;

import java.util.Scanner;

public class PersonMain {
	public static void main(String[] args) {
		
		Person p2 = new Person("Dexter","Morgan",'M',987456232);
		p2.showPersonDetails();
		
		
	}
}
