package com.lab2_5;

import com.lab2_5.*;

public class PersonMain {
	public static void main(String[] args) {
		Person p2 = new Person("Dexter", "Morgan", Gender.M, 987456232);
		p2.showPersonDetails();
	}

}
