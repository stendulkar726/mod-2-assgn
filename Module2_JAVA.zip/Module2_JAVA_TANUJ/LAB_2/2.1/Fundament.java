//2.1 Java program to print person details .

package com.cg.lab2;

public class Fundament {

	public static void main(String[] args) {
		System.out.println("Person Details:");
		System.out.println("____________________________");
		System.out.println();
		System.out.println("First Name: Divya");
		System.out.println("Last Name: Bharathi");
		System.out.println("Gender: F");
		System.out.println("Age: 20");
		System.out.println("Weight: 85.55");

	}

}
